$(document).ready(function () {          
  $('#datepicker1').datepicker({
      format: "mm/dd/yyyy"
  });  
  $('#datepicker2').datepicker({
      format: "mm/dd/yyyy"
  });  
});
